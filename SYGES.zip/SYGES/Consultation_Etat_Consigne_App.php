<?php
if (isset ($_SESSION['habilitation']) && ($_SESSION['habilitation']=="Administrateur"))
{
	include('Connexion.php');
	include('fonctions.php');
	$Debut=dateFormatAnglais($_GET['DateD']);
	$Fin=dateFormatAnglais($_GET['DateF']);
	if ($_GET['Stat']=='Mixte')
	{	
	$sql='SELECT C.ID_APPRO, C.ID_EMBALLAGE, C.DATE_CONSIGNE, C.QTE, C.STATUT, C.PU, C.MONTANT, E.ID_EMBALLAGE, E.LIBELLE FROM CONSIGNEAPP C, EMBALLAGE E WHERE C.ID_EMBALLAGE=E.ID_EMBALLAGE AND C.DATE_CONSIGNE BETWEEN "'.$Debut.'" AND "'.$Fin.'" ORDER BY C.ID_APPRO';
	}
	else
		if ($_GET['Stat']=='NV')
		{
			$sql='SELECT C.ID_APPRO, C.ID_EMBALLAGE, C.DATE_CONSIGNE, C.QTE, C.STATUT, C.PU, C.MONTANT, E.ID_EMBALLAGE, E.LIBELLE FROM CONSIGNEAPP C, EMBALLAGE E WHERE C.ID_EMBALLAGE=E.ID_EMBALLAGE AND C.DATE_CONSIGNE BETWEEN "'.$Debut.'" AND "'.$Fin.'" AND C.STATUT="NV" ORDER BY C.ID_APPRO';
		}
		else
		{
			$sql='SELECT C.ID_APPRO, C.ID_EMBALLAGE, C.DATE_CONSIGNE, C.QTE, C.STATUT, C.PU, C.MONTANT, E.ID_EMBALLAGE, E.LIBELLE FROM CONSIGNEAPP C, EMBALLAGE E WHERE C.ID_EMBALLAGE=E.ID_EMBALLAGE AND C.DATE_CONSIGNE BETWEEN "'.$Debut.'" AND "'.$Fin.'" AND C.STATUT!="NV" ORDER BY C.ID_APPRO';
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Consultation de la Liste des Consignes</title>
</head>

<body>
<table id='liste' border="1" width="100%" align="center">
          <tr align="center" bgcolor="#CCCCCC">
          	<td colspan="10"><h3>Etat des Consignes Appro </h3></td>
          </tr>
          <tr align="center" bgcolor="#CCCCCC">
          		<td colspan="4"><h5>Période Du : <?php echo dateFormatFrancais($Debut); ?> Au : <?php echo dateFormatFrancais($Fin); ?></h5></td>
                <td colspan="5" align="center"><h5>Statut : <?php echo $_GET['Stat']; ?></h5></td>
          </tr>
            <tr bgcolor="#CCCCCC">
                <td align="center" ><h5>Date Appro </h5> </td>
                <td align="left" ><h5>Code </h5> </td>
                <td align="left" ><h5>Fournisseur </h5> </td>
                <td align="center"><h5>Date Consigne </h5> </td>
                <td align="center" ><h5>Emballage </h5> </td>
                <td align="center" ><h5>Qte </h5> </td>
                <td  align="center"><h5>PU </h5></td>
				<td align="center" ><h5>Montant </h5></td>
                <td align="left" ><h5>statut </h5></td>
			</tr>
            
<?php
$MT=0;
$couleur = "darkgray";
$i = 0;
$nbre=0;
$reponse= $DataBase->query($sql);
while($rslt= $reponse->fetch())
{
 //ici on recupere la date de la vente et le client
	 $sql1 = 'SELECT A.ID_APPRO, A.DATE_APPRO, A.ID_FOURNISSEUR, F.ID_FOURNISSEUR, F.NOM FROM APPROVISIONNEMENT A, FOURNISSEUR F WHERE A.ID_FOURNISSEUR=A.ID_FOURNISSEUR AND A.ID_APPRO="'.$rslt['ID_APPRO'].'"';
	$reponse1= $DataBase->query($sql1);
		while($rslt2= $reponse1->fetch())
		{
			$date=$rslt2['DATE_APPRO'];
    		$nom=$rslt2['NOM'];
		}

 
			if ($i%2 == 0)
					$couleur = '#CCCCCC';
				else
					$couleur = "white";
				echo "<tr bgcolor=$couleur>";
				?>
                		<td  align="center"> <?php echo dateFormatFrancais($date); ?> </td>
                        <td  align="left"> <?php echo $rslt['ID_APPRO']; ?> </td>
                        <td  align="left"> <?php echo $nom; ?> </td>
                        <td  align="center"> <?php echo dateFormatFrancais($rslt['DATE_CONSIGNE']); ?> </td>
                        <td  align="center"> <?php echo $rslt['LIBELLE']; ?> </td>
                        <td  align="center"> <?php echo $rslt['QTE'];?> </td>
                        <td  align="center"> <?php echo $rslt['PU'].' FCFA'; ?> </td>
                        <td  align="center"> <?php echo $rslt['MONTANT'].' FCFA'; ?> </td>
                        <td  align="left"> <?php echo $rslt['STATUT']; ?> </td>
                     </tr>
                <?php
				$i++;
				$nbre++;
				$MT = ($MT + $rslt['MONTANT']);
		 }
?>
<tr>
		<td><a href="Etat_Consigne_App.php?debut=<?php echo $_GET["DateD"];?>&fin=<?php echo $_GET["DateF"];?>&Stat=<?php echo $_GET['Stat'];?>"/><input type="button" value="Imprimer" /></td></a>
	<td colspan="2"><h4>Nombre de consigne :  <?php echo $nbre; ?> </h4></td>
    <td align="center" colspan="6"><h4>Total Montant Consigne : <?php echo $MT.' FCFA'; ?> </h4></td>
</tr>
</table>
</body>
</html>
<?php 
}
else
{
?>
				<script language="javascript" type="text/javascript">
				alert('Vous n\'etes pas habiliter a  acceder a cette page.');
				history.back();
				</script>
<?php
}
?>